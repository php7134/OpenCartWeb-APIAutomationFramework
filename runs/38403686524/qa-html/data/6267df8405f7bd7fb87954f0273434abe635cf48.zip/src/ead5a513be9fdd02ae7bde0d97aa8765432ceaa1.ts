import {test,expect} from '../src/fixtures/pagefixtures';   


test.beforeEach(async({loginPage})=>
{
    await loginPage.goToLoginPage();
    await loginPage.doLogin(process.env.USERNAME!, process.env.PASSWORD!);

});

test('@smoke verify product header', async ({homePage, searchResultsPage, productInfoPage})=>{

    await homePage.doSearch('macbook'); 
    await searchResultsPage.selectProduct('MacBook Pro');
    expect(await productInfoPage.getProductHeader()).toBe('MacBook Pro'); 

});

test('@regression verify product images count', async ({homePage, searchResultsPage, productInfoPage})=>{

    await homePage.doSearch('macbook'); 
    await searchResultsPage.selectProduct('MacBook Air');
    //await page.pause();
    expect(await productInfoPage.getProductImagesCount()).toBe(4); 
    //await page.pause();

});

test('@regression verify product information/data count', async ({homePage, searchResultsPage, productInfoPage})=>{

    await homePage.doSearch('macbook'); 
    await searchResultsPage.selectProduct('MacBook Pro');
    let actualProductInfoMap =await productInfoPage.getProductInfo();
    console.log('Actual Product Details: ', actualProductInfoMap);

    expect.soft(actualProductInfoMap.get('productheader')).toBe('MacBook Pro');
    expect.soft(actualProductInfoMap.get('productImagesCount')).toBe(4);
    expect.soft(actualProductInfoMap.get('Brand')).toBe('Apple');
    expect.soft(actualProductInfoMap.get('Product Code')).toBe('Product 18');
    expect.soft(actualProductInfoMap.get('Reward Points')).toBe('800');
    expect.soft(actualProductInfoMap.get('Availability')).toBe('Out Of Stock');

    expect.soft(actualProductInfoMap.get('productPrice')).toBe('$2,000.00');
    expect.soft(actualProductInfoMap.get('exTaxPrice')).toBe('$2,000.00');


    //await page.pause();

});


//common features test:

test('@smoke App logo exists on Login Page', async({basePage})=>{
    expect (await basePage.isLogoVisible()).toBeTruthy();
});


test('@smoke Search Box exists on Login Page', async({basePage})=>{
    expect (await basePage.isSearchBoxVisible()).toBeTruthy();
});

test('@smoke Cart exists on Login Page', async({basePage})=>{
    expect (await basePage.isCartButtonVisible()).toBeTruthy();
});

test('@smoke Footers exists on Login Page', async({basePage})=>{
    expect (await basePage.getPageFootersCount()).toBe(16);
});
